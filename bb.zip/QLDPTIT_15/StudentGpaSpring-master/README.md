# StudentGpaSpring
View and calculate automactically student gpa
